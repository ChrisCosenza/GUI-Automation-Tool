﻿[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void][Reflection.Assembly]::LoadWithPartialName("System.Drawing")

# ============================================================
# V3 AUTOMATION RECORDER
#
# F8 = Start recording
# F9 = Stop recording
#
# Records:
#   Keyboard
#   Mouse movement
#   Left click
#   Right click
#   Timing
#
# Generates:
#   RecordedAutomation.ps1
# ============================================================


# ============================================================
# INPUT HELPER
# ============================================================

$inputCode = @"
using System;
using System.Text;
using System.Runtime.InteropServices;

public class InputHelper
{
    [DllImport("user32.dll")]
    private static extern short GetAsyncKeyState(int vKey);

    [DllImport("user32.dll")]
    private static extern bool GetKeyboardState(byte[] lpKeyState);

    [DllImport("user32.dll")]
    private static extern uint MapVirtualKey(uint uCode, uint uMapType);

    [DllImport("user32.dll")]
    private static extern int ToUnicode(
        uint wVirtKey,
        uint wScanCode,
        byte[] lpKeyState,
        [Out, MarshalAs(UnmanagedType.LPWStr)]
        StringBuilder pwszBuff,
        int cchBuff,
        uint wFlags);

    [DllImport("user32.dll")]
    private static extern bool GetCursorPos(out POINT lpPoint);

    [StructLayout(LayoutKind.Sequential)]
    public struct POINT
    {
        public int X;
        public int Y;
    }

    private static bool[] oldKeys = new bool[256];

    private static bool oldLeft = false;
    private static bool oldRight = false;

    private static int oldX = -1;
    private static int oldY = -1;


    public static void Reset()
    {
        int i;

        for (i = 0; i < 256; i++)
        {
            oldKeys[i] =
                (GetAsyncKeyState(i) & 0x8000) != 0;
        }

        oldLeft =
            (GetAsyncKeyState(0x01) & 0x8000) != 0;

        oldRight =
            (GetAsyncKeyState(0x02) & 0x8000) != 0;

        POINT p;

        if (GetCursorPos(out p))
        {
            oldX = p.X;
            oldY = p.Y;
        }
    }


    private static bool IsDown(int vk)
    {
        return
            (GetAsyncKeyState(vk) & 0x8000) != 0;
    }


    private static string TranslateKey(int vk)
    {
        // ENTER
        if (vk == 0x0D)
            return "{ENTER}";

        // TAB
        if (vk == 0x09)
            return "{TAB}";

        // BACKSPACE
        if (vk == 0x08)
            return "{BACKSPACE}";

        // ESCAPE
        if (vk == 0x1B)
            return "{ESC}";

        // SPACE
        if (vk == 0x20)
            return " ";

        // Ignore F1-F12.
        // F8 starts recording.
        // F9 stops recording.

        if (vk >= 0x70 && vk <= 0x7B)
            return "";

        byte[] keyboardState =
            new byte[256];

        if (!GetKeyboardState(keyboardState))
            return "";

        uint scanCode =
            MapVirtualKey((uint)vk, 0);

        StringBuilder buffer =
            new StringBuilder(8);

        int result =
            ToUnicode(
                (uint)vk,
                scanCode,
                keyboardState,
                buffer,
                buffer.Capacity,
                0);

        if (result > 0)
            return buffer.ToString();

        return "";
    }


    public static string GetKeyboardEvent()
    {
        int vk;

        for (vk = 1; vk < 256; vk++)
        {
            bool current =
                IsDown(vk);

            if (current && !oldKeys[vk])
            {
                oldKeys[vk] = true;

                string text =
                    TranslateKey(vk);

                if (text != "")
                    return text;
            }

            oldKeys[vk] = current;
        }

        return "";
    }


    public static string GetMouseEvents()
    {
        StringBuilder events =
            new StringBuilder();

        bool left =
            IsDown(0x01);

        bool right =
            IsDown(0x02);


        // LEFT CLICK

        if (left && !oldLeft)
        {
            events.Append("LEFT|");
        }


        // RIGHT CLICK

        if (right && !oldRight)
        {
            events.Append("RIGHT|");
        }


        oldLeft = left;
        oldRight = right;


        // MOUSE MOVEMENT

        POINT p;

        if (GetCursorPos(out p))
        {
            if (oldX == -1 || oldY == -1)
            {
                oldX = p.X;
                oldY = p.Y;
            }
            else
            {
                if (p.X != oldX || p.Y != oldY)
                {
                    events.Append("MOVE|");
                    events.Append(p.X);
                    events.Append("|");
                    events.Append(p.Y);
                    events.Append("|");

                    oldX = p.X;
                    oldY = p.Y;
                }
            }
        }

        return events.ToString();
    }
}
"@


# ============================================================
# COMPILE INPUT HELPER
# ============================================================

$provider =
    New-Object Microsoft.CSharp.CSharpCodeProvider

$compileParams =
    New-Object System.CodeDom.Compiler.CompilerParameters

$compileParams.GenerateInMemory = $true
$compileParams.GenerateExecutable = $false

[void]$compileParams.ReferencedAssemblies.Add("System.dll")
[void]$compileParams.ReferencedAssemblies.Add("System.Drawing.dll")

$result =
    $provider.CompileAssemblyFromSource(
        $compileParams,
        $inputCode
    )


if ($result.Errors.Count -gt 0)
{
    Write-Host ""
    Write-Host "Input helper compilation failed."
    Write-Host ""

    foreach ($error in $result.Errors)
    {
        Write-Host $error
    }

    exit
}


# ============================================================
# CONTROL HELPER
# ============================================================

$controlCode = @"
using System;
using System.Runtime.InteropServices;

public class RecorderControl
{
    [DllImport("user32.dll")]
    private static extern short GetAsyncKeyState(int vKey);

    public static bool IsDown(int vKey)
    {
        return
            (GetAsyncKeyState(vKey) & 0x8000) != 0;
    }
}
"@


$controlResult =
    $provider.CompileAssemblyFromSource(
        $compileParams,
        $controlCode
    )


if ($controlResult.Errors.Count -gt 0)
{
    Write-Host ""
    Write-Host "Control helper compilation failed."
    Write-Host ""

    foreach ($error in $controlResult.Errors)
    {
        Write-Host $error
    }

    exit
}


# ============================================================
# INTRODUCTION
# ============================================================

Write-Host ""
Write-Host "==============================================="
Write-Host "        AUTOMATION RECORDER V3"
Write-Host "==============================================="
Write-Host ""

Write-Host "F8 = START"
Write-Host "F9 = STOP"
Write-Host ""

Write-Host "Records:"
Write-Host "  Keyboard"
Write-Host "  Mouse movement"
Write-Host "  Left click"
Write-Host "  Right click"
Write-Host "  Timing"
Write-Host ""

Write-Host "Press F8 to start."
Write-Host ""


# ============================================================
# WAIT FOR F8
# ============================================================

while (-not [RecorderControl]::IsDown(0x77))
{
    Start-Sleep -Milliseconds 30
}


# Wait for F8 to be released.

while ([RecorderControl]::IsDown(0x77))
{
    Start-Sleep -Milliseconds 20
}


# Reset all keyboard/mouse states.

[InputHelper]::Reset()


# ============================================================
# START RECORDING
# ============================================================

Write-Host ""
Write-Host "==============================================="
Write-Host "             RECORDING..."
Write-Host "==============================================="
Write-Host ""
Write-Host "Press F9 to stop."
Write-Host ""


$events =
    New-Object System.Collections.ArrayList


$watch =
    New-Object System.Diagnostics.Stopwatch

$watch.Start()


$lastEventTime = 0

$recording = $true


# ============================================================
# RECORDING LOOP
# ============================================================

while ($recording)
{
    # --------------------------------------------------------
    # CHECK F9
    # --------------------------------------------------------

    if ([RecorderControl]::IsDown(0x78))
    {
        $recording = $false
        break
    }


    # --------------------------------------------------------
    # KEYBOARD
    # --------------------------------------------------------

    $key =
        [InputHelper]::GetKeyboardEvent()


    if ($key -ne "")
    {
        $now =
            $watch.ElapsedMilliseconds

        $delay =
            $now - $lastEventTime


        $event =
            New-Object PSObject


        $event |
            Add-Member NoteProperty Type "KEY"

        $event |
            Add-Member NoteProperty Value $key

        $event |
            Add-Member NoteProperty X 0

        $event |
            Add-Member NoteProperty Y 0

        $event |
            Add-Member NoteProperty Delay $delay


        [void]$events.Add($event)


        $lastEventTime =
            $now


        Write-Host (
            "KEY       {0}   +{1}ms" -f
            $key,
            $delay
        )
    }


    # --------------------------------------------------------
    # MOUSE
    # --------------------------------------------------------

    $mouseData =
        [InputHelper]::GetMouseEvents()


    if ($mouseData -ne "")
    {
        $parts =
            $mouseData.Split("|")


        $i = 0


        while ($i -lt ($parts.Length - 1))
        {
            $type =
                $parts[$i]


            # ------------------------------------------------
            # LEFT CLICK
            # ------------------------------------------------

            if ($type -eq "LEFT")
            {
                $now =
                    $watch.ElapsedMilliseconds

                $delay =
                    $now - $lastEventTime

                $pos =
                    [System.Windows.Forms.Cursor]::Position


                $event =
                    New-Object PSObject


                $event |
                    Add-Member NoteProperty Type "LEFT"

                $event |
                    Add-Member NoteProperty Value ""

                $event |
                    Add-Member NoteProperty X $pos.X

                $event |
                    Add-Member NoteProperty Y $pos.Y

                $event |
                    Add-Member NoteProperty Delay $delay


                [void]$events.Add($event)


                $lastEventTime =
                    $now


                Write-Host (
                    "LEFT CLICK  {0},{1}   +{2}ms" -f
                    $pos.X,
                    $pos.Y,
                    $delay
                )


                $i++
            }


            # ------------------------------------------------
            # RIGHT CLICK
            # ------------------------------------------------

            elseif ($type -eq "RIGHT")
            {
                $now =
                    $watch.ElapsedMilliseconds

                $delay =
                    $now - $lastEventTime

                $pos =
                    [System.Windows.Forms.Cursor]::Position


                $event =
                    New-Object PSObject


                $event |
                    Add-Member NoteProperty Type "RIGHT"

                $event |
                    Add-Member NoteProperty Value ""

                $event |
                    Add-Member NoteProperty X $pos.X

                $event |
                    Add-Member NoteProperty Y $pos.Y

                $event |
                    Add-Member NoteProperty Delay $delay


                [void]$events.Add($event)


                $lastEventTime =
                    $now


                Write-Host (
                    "RIGHT CLICK {0},{1}   +{2}ms" -f
                    $pos.X,
                    $pos.Y,
                    $delay
                )


                $i++
            }


            # ------------------------------------------------
            # MOVE
            # ------------------------------------------------

            elseif ($type -eq "MOVE")
            {
                if (($i + 2) -lt $parts.Length)
                {
                    $x =
                        [int]$parts[$i + 1]

                    $y =
                        [int]$parts[$i + 2]


                    $now =
                        $watch.ElapsedMilliseconds

                    $delay =
                        $now - $lastEventTime


                    $event =
                        New-Object PSObject


                    $event |
                        Add-Member NoteProperty Type "MOVE"

                    $event |
                        Add-Member NoteProperty Value ""

                    $event |
                        Add-Member NoteProperty X $x

                    $event |
                        Add-Member NoteProperty Y $y

                    $event |
                        Add-Member NoteProperty Delay $delay


                    [void]$events.Add($event)


                    $lastEventTime =
                        $now


                    Write-Host (
                        "MOVE        {0},{1}   +{2}ms" -f
                        $x,
                        $y,
                        $delay
                    )


                    $i += 3
                }
                else
                {
                    $i++
                }
            }
            else
            {
                $i++
            }
        }
    }


    # --------------------------------------------------------
    # POLL RATE
    # --------------------------------------------------------

    Start-Sleep -Milliseconds 15
}


$watch.Stop()


# Wait for F9 release.

while ([RecorderControl]::IsDown(0x78))
{
    Start-Sleep -Milliseconds 20
}


# ============================================================
# GENERATE REPLAY SCRIPT
# ============================================================

$output =
    Join-Path (Get-Location) "RecordedAutomation.ps1"


# We deliberately build this script line-by-line.
# This avoids PowerShell v1 nested here-string/parser problems.

$lines =
    New-Object System.Collections.ArrayList


# ------------------------------------------------------------
# REPLAY SCRIPT HEADER
# ------------------------------------------------------------

[void]$lines.Add(
    '[void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")'
)

[void]$lines.Add(
    '[void][Reflection.Assembly]::LoadWithPartialName("System.Drawing")'
)

[void]$lines.Add("")


# ------------------------------------------------------------
# MOUSE HELPER
# ------------------------------------------------------------

[void]$lines.Add('$mouseCode = @"')

[void]$lines.Add('using System;')

[void]$lines.Add('using System.Runtime.InteropServices;')

[void]$lines.Add("")

[void]$lines.Add('public class MouseReplay')

[void]$lines.Add('{')

[void]$lines.Add('    [DllImport("user32.dll")]')

[void]$lines.Add('    public static extern void mouse_event(')

[void]$lines.Add('        uint flags,')

[void]$lines.Add('        uint dx,')

[void]$lines.Add('        uint dy,')

[void]$lines.Add('        uint data,')

[void]$lines.Add('        uint extraInfo);')

[void]$lines.Add('}')

[void]$lines.Add('"@')

[void]$lines.Add("")


# ------------------------------------------------------------
# COMPILE MOUSE HELPER
# ------------------------------------------------------------

[void]$lines.Add(
    '$provider = New-Object Microsoft.CSharp.CSharpCodeProvider'
)

[void]$lines.Add(
    '$params = New-Object System.CodeDom.Compiler.CompilerParameters'
)

[void]$lines.Add(
    '$params.GenerateInMemory = $true'
)

[void]$lines.Add(
    '$params.GenerateExecutable = $false'
)

[void]$lines.Add(
    '[void]$params.ReferencedAssemblies.Add("System.dll")'
)

[void]$lines.Add(
    '$result = $provider.CompileAssemblyFromSource($params,$mouseCode)'
)

[void]$lines.Add("")

[void]$lines.Add(
    'if ($result.Errors.Count -gt 0)'
)

[void]$lines.Add('{')

[void]$lines.Add(
    '    Write-Host "Mouse helper compilation failed."'
)

[void]$lines.Add(
    '    exit'
)

[void]$lines.Add('}')

[void]$lines.Add("")


# ------------------------------------------------------------
# REPLAY START
# ------------------------------------------------------------

[void]$lines.Add(
    'Write-Host ""'
)

[void]$lines.Add(
    'Write-Host "==============================================="'
)

[void]$lines.Add(
    'Write-Host "       REPLAYING AUTOMATION"'
)

[void]$lines.Add(
    'Write-Host "==============================================="'
)

[void]$lines.Add(
    'Write-Host ""'
)

[void]$lines.Add(
    'Write-Host "Starting in 3 seconds..."'
)

[void]$lines.Add(
    'Start-Sleep -Seconds 3'
)

[void]$lines.Add("")


# ============================================================
# ADD RECORDED EVENTS
# ============================================================

foreach ($event in $events)
{
    $delay =
        [int]$event.Delay


    # --------------------------------------------------------
    # DELAY
    # --------------------------------------------------------

    if ($delay -gt 0)
    {
        [void]$lines.Add(
            ('Start-Sleep -Milliseconds {0}' -f $delay)
        )
    }


    # --------------------------------------------------------
    # KEY
    # --------------------------------------------------------

    if ($event.Type -eq "KEY")
    {
        $value =
            $event.Value.Replace('"','""')


        $line =
            '[System.Windows.Forms.SendKeys]::SendWait("' +
            $value +
            '")'


        [void]$lines.Add($line)
    }


    # --------------------------------------------------------
    # MOUSE MOVE
    # --------------------------------------------------------

    elseif ($event.Type -eq "MOVE")
    {
        $x =
            $event.X

        $y =
            $event.Y


        $line =
            '[System.Windows.Forms.Cursor]::Position = ' +
            'New-Object System.Drawing.Point(' +
            $x +
            ',' +
            $y +
            ')'


        [void]$lines.Add($line)
    }


    # --------------------------------------------------------
    # LEFT CLICK
    # --------------------------------------------------------

    elseif ($event.Type -eq "LEFT")
    {
        $x =
            $event.X

        $y =
            $event.Y


        [void]$lines.Add(
            '[System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point(' +
            $x +
            ',' +
            $y +
            ')'
        )


        [void]$lines.Add(
            '[MouseReplay]::mouse_event(0x0002,0,0,0,0)'
        )


        [void]$lines.Add(
            '[MouseReplay]::mouse_event(0x0004,0,0,0,0)'
        )
    }


    # --------------------------------------------------------
    # RIGHT CLICK
    # --------------------------------------------------------

    elseif ($event.Type -eq "RIGHT")
    {
        $x =
            $event.X

        $y =
            $event.Y


        [void]$lines.Add(
            '[System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point(' +
            $x +
            ',' +
            $y +
            ')'
        )


        [void]$lines.Add(
            '[MouseReplay]::mouse_event(0x0008,0,0,0,0)'
        )


        [void]$lines.Add(
            '[MouseReplay]::mouse_event(0x0010,0,0,0,0)'
        )
    }
}


# ============================================================
# REPLAY END
# ============================================================

[void]$lines.Add("")

[void]$lines.Add(
    'Write-Host ""'
)

[void]$lines.Add(
    'Write-Host "Replay complete."'
)


# ============================================================
# WRITE GENERATED SCRIPT
# ============================================================

[System.IO.File]::WriteAllLines(
    $output,
    $lines.ToArray(),
    [System.Text.Encoding]::ASCII
)


# ============================================================
# SUMMARY
# ============================================================

Write-Host ""
Write-Host "==============================================="
Write-Host "         RECORDING COMPLETE"
Write-Host "==============================================="
Write-Host ""

Write-Host (
    "Events recorded: {0}" -f
    $events.Count
)

Write-Host ""

Write-Host "Generated:"
Write-Host $output

Write-Host ""

Write-Host "To replay:"
Write-Host "powershell -ExecutionPolicy Bypass -File RecordedAutomation.ps1"

Write-Host ""